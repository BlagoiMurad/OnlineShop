const API = 'https://localhost:7222'; // променете според вашия бекенд URL
let token = localStorage.getItem('nx_token');
let allProducts = [];
let allCategories = [];
let editingProductId = null;
let cart = JSON.parse(localStorage.getItem('nx_cart') || '[]');

if (token) showApp();


function switchAuthTab(tab) {
  document.querySelectorAll('.atab').forEach((t, i) =>
    t.classList.toggle('active', (i === 0 && tab === 'login') || (i === 1 && tab === 'register'))
  );
  document.getElementById('loginPanel').classList.toggle('active', tab === 'login');
  document.getElementById('registerPanel').classList.toggle('active', tab === 'register');
}

async function login() {
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  try {
    const res = await fetch(`${API}/api/auth/login`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    if (!res.ok) { showToast('Invalid credentials', true); return; }
    const data = await res.json();
    token = data.token;
    localStorage.setItem('nx_token', token);
    showApp();
  } catch { showToast('Cannot connect to API. Is the server running?', true); }
}

async function register() {
  const firstName = document.getElementById('regFirst').value.trim();
  const lastName = document.getElementById('regLast').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const password = document.getElementById('regPassword').value;

  if (!firstName || !lastName || !email || !password) {
    showToast('Please fill in all fields', true); return;
  }

  const body = { firstName, lastName, email, password };
  try {
    const res = await fetch(`${API}/api/auth/register`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    if (!res.ok) {
      try {
        const err = await res.json();
        const msg = err.errors
          ? Object.values(err.errors).flat().join(', ')
          : err.message || 'Registration failed';
        showToast(msg, true);
      } catch { showToast('Registration failed', true); }
      return;
    }
    showToast('Account created! Sign in now.');
    switchAuthTab('login');
  } catch { showToast('Cannot connect to API', true); }
}

function showApp() {
  document.getElementById('authPage').classList.add('hidden');
  document.getElementById('appPage').classList.remove('hidden');
  loadDashboard();
  loadCategories();
  updateCartBadge();
  if (isAdmin()) {
    const addProductBtn = document.getElementById('addProductBtn');
    if (addProductBtn) addProductBtn.classList.remove('hidden');
  }
}

function logout() {
  localStorage.removeItem('nx_token');
  token = null;
  document.getElementById('authPage').classList.remove('hidden');
  document.getElementById('appPage').classList.add('hidden');
}

function getUserIdFromToken() {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    return payload['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] || payload.sub || '';
  } catch { return ''; }
}

function isAdmin() {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const role = payload['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'] || payload.role || '';
    return Array.isArray(role) ? role.includes('Administrator') : role === 'Administrator';
  } catch { return false; }
}

// ── NAVIGATION ──
function showSection(name, el) {
  document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
  document.querySelectorAll('.tnav').forEach(n => n.classList.remove('active'));
  document.getElementById(name + 'Section').classList.add('active');
  if (el) el.classList.add('active');
  if (name === 'products') loadProducts();
  if (name === 'categories') loadCategoriesPage();
  if (name === 'orders') loadOrders();
  if (name === 'cart') renderCart();
  if (name === 'myorders') loadMyOrders();
}

function headers() {
  return { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` };
}

// ── DASHBOARD ──
async function loadDashboard() {
  try {
    const [products, categories] = await Promise.all([
      fetch(`${API}/api/products`, { headers: headers() }).then(r => r.json()),
      fetch(`${API}/api/categories`, { headers: headers() }).then(r => r.json())
    ]);
    allProducts = products;
    allCategories = categories;
    document.getElementById('kpiProducts').textContent = products.length;
    document.getElementById('kpiCategories').textContent = categories.length;

    const container = document.getElementById('dashProducts');
    container.innerHTML = products.slice(0, 5).map(p => `
      <div class="pcard">
        <div class="pcard-img">${getEmoji(p.categoryName)}</div>
        <div class="pcard-info">
          <div class="pcard-name">${p.name}</div>
          <div class="pcard-cat">${p.categoryName || '—'}</div>
        </div>
        <div class="pcard-price">$${p.price.toFixed(2)}</div>
      </div>`).join('');

    const catContainer = document.getElementById('dashCategories');
    catContainer.innerHTML = categories.map(c => `
      <div class="cat-pill" onclick="filterByCategoryFromDash(${c.id})">
        <span>${c.name}</span>
        <span class="cat-pill-icon">${getCatEmoji(c.name)}</span>
      </div>`).join('');

    try {
      const orders = await fetch(`${API}/api/orders`, { headers: headers() }).then(r => r.json());
      document.getElementById('kpiOrders').textContent = orders.length;
    } catch { document.getElementById('kpiOrders').textContent = '—'; }
  } catch (e) { console.error(e); }
}

function filterByCategoryFromDash(catId) {
  showSection('products', document.querySelector('.tnav:nth-child(2)'));
  setTimeout(() => {
    document.getElementById('filterCategory').value = catId;
    filterByCategory(catId);
  }, 100);
}

// ── PRODUCTS ──
async function loadProducts() {
  const grid = document.getElementById('productGrid');
  grid.innerHTML = loadingHTML();
  try {
    const res = await fetch(`${API}/api/products`, { headers: headers() });
    allProducts = await res.json();
    populateCategoryFilter();
    renderProductGrid(allProducts);
  } catch { grid.innerHTML = errorHTML('Failed to load products'); }
}

function renderProductGrid(products) {
  const grid = document.getElementById('productGrid');
  if (!products.length) {
    grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-state-icon">📭</div><h3>No products found</h3></div>`;
    return;
  }
  grid.innerHTML = products.map(p => {
    const stockClass = p.stock > 10 ? 'stock-high' : p.stock > 0 ? 'stock-low' : 'stock-out';
    const stockLabel = p.stock > 10 ? `${p.stock} in stock` : p.stock > 0 ? `Only ${p.stock} left` : 'Out of stock';
    const imgContent = p.imageUrl
      ? `<img src="${p.imageUrl}" alt="${p.name}" onerror="this.parentNode.innerHTML='<span class=pg-img-placeholder>${getEmoji(p.categoryName)}</span>'">`
      : `<span class="pg-img-placeholder">${getEmoji(p.categoryName)}</span>`;
    const inCart = cart.find(c => c.productId === p.id);
    const adminBtns = isAdmin() ? `
              <button class="pg-btn" onclick="editProduct(${p.id})" title="Edit">✏️</button>
              <button class="pg-btn del" onclick="deleteProduct(${p.id})" title="Delete">🗑️</button>` : '';
    return `
      <div class="pg-card">
        <div class="pg-img">
          ${imgContent}
          <span class="pg-stock-badge ${stockClass}">${stockLabel}</span>
        </div>
        <div class="pg-body">
          <div class="pg-cat">${p.categoryName || 'Uncategorized'}</div>
          <div class="pg-name">${p.name}</div>
          <div class="pg-desc">${p.description || 'No description'}</div>
          <div class="pg-footer">
            <div class="pg-price">$${p.price.toFixed(2)}</div>
            <div class="pg-actions">
              <button class="pg-btn cart-btn ${inCart ? 'in-cart' : ''}" onclick="addToCart(${p.id}, '${p.name}', ${p.price})" title="Add to cart">🛒</button>
              ${adminBtns}
            </div>
          </div>
        </div>
      </div>`;
  }).join('');
}

function filterProductsLocal(q) {
  const catId = document.getElementById('filterCategory').value;
  let filtered = allProducts.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  if (catId) filtered = filtered.filter(p => p.categoryId == catId);
  renderProductGrid(filtered);
}

function filterByCategory(catId) {
  const q = document.querySelector('.filter-input')?.value || '';
  let filtered = allProducts;
  if (catId) filtered = filtered.filter(p => p.categoryId == catId);
  if (q) filtered = filtered.filter(p => p.name.toLowerCase().includes(q.toLowerCase()));
  renderProductGrid(filtered);
}

function populateCategoryFilter() {
  const sel = document.getElementById('filterCategory');
  sel.innerHTML = '<option value="">All categories</option>' +
    allCategories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
}

async function openModal(type) {
  if (type === 'addProduct') {
    editingProductId = null;
    document.getElementById('productModalTitle').textContent = 'Add Product';
    document.getElementById('pName').value = '';
    document.getElementById('pDesc').value = '';
    document.getElementById('pPrice').value = '';
    document.getElementById('pStock').value = '';
    document.getElementById('pImage').value = '';
    document.getElementById('pCategory').innerHTML = allCategories.map(c =>
      `<option value="${c.id}">${c.name}</option>`).join('');
    document.getElementById('addProductModal').classList.remove('hidden');
    document.getElementById('modalOverlay').classList.remove('hidden');
  } else if (type === 'addCategory') {
    document.getElementById('cName').value = '';
    document.getElementById('cDesc').value = '';
    document.getElementById('addCategoryModal').classList.remove('hidden');
    document.getElementById('modalOverlay').classList.remove('hidden');
  }
}

async function editProduct(id) {
  editingProductId = id;
  const p = allProducts.find(x => x.id === id);
  if (!p) return;
  document.getElementById('productModalTitle').textContent = 'Edit Product';
  document.getElementById('pName').value = p.name;
  document.getElementById('pDesc').value = p.description || '';
  document.getElementById('pPrice').value = p.price;
  document.getElementById('pStock').value = p.stock;
  document.getElementById('pImage').value = p.imageUrl || '';
  document.getElementById('pCategory').innerHTML = allCategories.map(c =>
    `<option value="${c.id}" ${c.id === p.categoryId ? 'selected' : ''}>${c.name}</option>`).join('');
  document.getElementById('addProductModal').classList.remove('hidden');
  document.getElementById('modalOverlay').classList.remove('hidden');
}

async function saveProduct() {
  const body = {
    name: document.getElementById('pName').value,
    description: document.getElementById('pDesc').value,
    price: parseFloat(document.getElementById('pPrice').value),
    stock: parseInt(document.getElementById('pStock').value),
    categoryId: parseInt(document.getElementById('pCategory').value),
    imageUrl: document.getElementById('pImage').value
  };
  const url = editingProductId ? `${API}/api/products/${editingProductId}` : `${API}/api/products`;
  const method = editingProductId ? 'PUT' : 'POST';
  try {
    const res = await fetch(url, { method, headers: headers(), body: JSON.stringify(body) });
    if (!res.ok) { showToast('Failed to save product', true); return; }
    closeModal('addProduct');
    showToast(editingProductId ? 'Product updated!' : 'Product added!');
    loadProducts();
    loadDashboard();
  } catch { showToast('Error saving product', true); }
}

async function deleteProduct(id) {
  if (!confirm('Delete this product?')) return;
  await fetch(`${API}/api/products/${id}`, { method: 'DELETE', headers: headers() });
  showToast('Product deleted');
  loadProducts();
  loadDashboard();
}

// ── CART ──
function addToCart(productId, name, price) {
  const existing = cart.find(c => c.productId === productId);
  if (existing) {
    existing.quantity++;
  } else {
    cart.push({ productId, name, price, quantity: 1 });
  }
  localStorage.setItem('nx_cart', JSON.stringify(cart));
  updateCartBadge();
  showToast(`${name} added to cart!`);
  renderProductGrid(allProducts);
}

function removeFromCart(productId) {
  cart = cart.filter(c => c.productId !== productId);
  localStorage.setItem('nx_cart', JSON.stringify(cart));
  updateCartBadge();
  renderCart();
}

function updateCartQty(productId, qty) {
  const item = cart.find(c => c.productId === productId);
  if (!item) return;
  if (qty < 1) { removeFromCart(productId); return; }
  item.quantity = qty;
  localStorage.setItem('nx_cart', JSON.stringify(cart));
  updateCartBadge();
  renderCart();
}

function updateCartBadge() {
  const total = cart.reduce((sum, c) => sum + c.quantity, 0);
  const badge = document.getElementById('cartBadge');
  if (badge) { badge.textContent = total; badge.classList.toggle('hidden', total === 0); }
}

function renderCart() {
  const container = document.getElementById('cartItems');
  const totalEl = document.getElementById('cartTotal');
  if (!container) return;

  if (!cart.length) {
    container.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🛒</div><h3>Your cart is empty</h3><p style="color:var(--muted);margin-top:8px">Browse products and add items</p></div>`;
    if (totalEl) totalEl.textContent = '$0.00';
    return;
  }

  container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="cart-item-img">${getEmoji('')}</div>
      <div class="cart-item-info">
        <div class="cart-item-name">${item.name}</div>
        <div class="cart-item-price">$${item.price.toFixed(2)} each</div>
      </div>
      <div class="cart-item-qty">
        <button class="qty-btn" onclick="updateCartQty(${item.productId}, ${item.quantity - 1})">−</button>
        <span>${item.quantity}</span>
        <button class="qty-btn" onclick="updateCartQty(${item.productId}, ${item.quantity + 1})">+</button>
      </div>
      <div class="cart-item-total">$${(item.price * item.quantity).toFixed(2)}</div>
      <button class="cart-remove" onclick="removeFromCart(${item.productId})">✕</button>
    </div>`).join('');

  const total = cart.reduce((sum, c) => sum + c.price * c.quantity, 0);
  if (totalEl) totalEl.textContent = `$${total.toFixed(2)}`;
  const finalEl = document.getElementById('cartTotalFinal');
  if (finalEl) finalEl.textContent = `$${total.toFixed(2)}`;
}

async function checkout() {
  if (!cart.length) { showToast('Cart is empty!', true); return; }
  const userId = getUserIdFromToken();
  if (!userId) { showToast('Please login again', true); return; }

  const order = {
    userId,
    orderItems: cart.map(c => ({
      productId: c.productId,
      quantity: c.quantity,
      price: c.price
    }))
  };

  try {
    const res = await fetch(`${API}/api/orders`, {
      method: 'POST', headers: headers(), body: JSON.stringify(order)
    });
    if (!res.ok) { showToast('Checkout failed', true); return; }
    cart = [];
    localStorage.setItem('nx_cart', JSON.stringify(cart));
    updateCartBadge();
    renderCart();
    showToast('Order placed successfully! 🎉');
    setTimeout(() => showSection('myorders', document.querySelector('.tnav[data-section="myorders"]')), 1500);
  } catch { showToast('Error placing order', true); }
}

// ── CATEGORIES ──
async function loadCategories() {
  try {
    const res = await fetch(`${API}/api/categories`, { headers: headers() });
    allCategories = await res.json();
  } catch { }
}

async function loadCategoriesPage() {
  const grid = document.getElementById('categoryGrid');
  grid.innerHTML = loadingHTML();
  try {
    const res = await fetch(`${API}/api/categories`, { headers: headers() });
    allCategories = await res.json();
    if (!allCategories.length) {
      grid.innerHTML = `<div class="empty-state" style="grid-column:1/-1"><div class="empty-state-icon">🗂️</div><h3>No categories yet</h3></div>`;
      return;
    }
    grid.innerHTML = allCategories.map(c => `
      <div class="cg-card">
        <div class="cg-icon">${getCatEmoji(c.name)}</div>
        <div class="cg-name">${c.name}</div>
        <div class="cg-desc">${c.description || 'No description'}</div>
        <div class="cg-footer">
          <button class="cg-del" onclick="deleteCategory(${c.id})">Delete</button>
        </div>
      </div>`).join('');
  } catch { grid.innerHTML = errorHTML('Failed to load categories'); }
}

async function saveCategory() {
  const body = {
    name: document.getElementById('cName').value,
    description: document.getElementById('cDesc').value
  };
  try {
    const res = await fetch(`${API}/api/categories`, {
      method: 'POST', headers: headers(), body: JSON.stringify(body)
    });
    if (!res.ok) { showToast('Failed to save', true); return; }
    closeModal('addCategory');
    showToast('Category added!');
    loadCategoriesPage();
    loadCategories();
    loadDashboard();
  } catch { showToast('Error', true); }
}

async function deleteCategory(id) {
  if (!confirm('Delete this category?')) return;
  await fetch(`${API}/api/categories/${id}`, { method: 'DELETE', headers: headers() });
  showToast('Category deleted');
  loadCategoriesPage();
  loadDashboard();
}

// ── ORDERS (Admin) ──
async function loadOrders() {
  const grid = document.getElementById('ordersGrid');
  grid.innerHTML = loadingHTML();
  try {
    const res = await fetch(`${API}/api/orders`, { headers: headers() });
    if (!res.ok) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🛒</div><h3>No orders yet</h3></div>`;
      return;
    }
    const orders = await res.json();
    document.getElementById('kpiOrders').textContent = orders.length;
    if (!orders.length) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-state-icon">🛒</div><h3>No orders yet</h3></div>`;
      return;
    }
    grid.innerHTML = renderOrdersList(orders);
  } catch { grid.innerHTML = errorHTML('Failed to load orders'); }
}

// ── MY ORDERS ──
async function loadMyOrders() {
  const grid = document.getElementById('myOrdersGrid');
  if (!grid) return;
  grid.innerHTML = loadingHTML();
  try {
    const userId = getUserIdFromToken();
    const res = await fetch(`${API}/api/orders/user/${userId}`, { headers: headers() });
    if (!res.ok) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📋</div><h3>No orders yet</h3></div>`;
      return;
    }
    const orders = await res.json();
    if (!orders.length) {
      grid.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📋</div><h3>No orders yet</h3></div>`;
      return;
    }
    grid.innerHTML = renderOrdersList(orders);
  } catch { grid.innerHTML = errorHTML('Failed to load orders'); }
}

function renderOrdersList(orders) {
  const statusMap = { 0: 'Pending', 1: 'Processing', 2: 'Shipped', 3: 'Delivered', 4: 'Cancelled' };
  const badgeMap = { 0: 'os-pending', 1: 'os-processing', 2: 'os-shipped', 3: 'os-delivered', 4: 'os-cancelled' };
  return orders.map(o => `
    <div class="order-card">
      <div class="order-id">#${o.id}</div>
      <div class="order-user">${o.userId.substring(0, 12)}...</div>
      <div class="order-total">$${o.totalPrice.toFixed(2)}</div>
      <div class="order-date">${new Date(o.createdAt).toLocaleDateString()}</div>
      <span class="order-status ${badgeMap[o.status] || 'os-pending'}">${statusMap[o.status] || 'Unknown'}</span>
    </div>`).join('');
}

// ── GLOBAL SEARCH ──
function globalSearchHandler(q) {
  if (!q) return;
  showSection('products', document.querySelector('.tnav:nth-child(2)'));
  setTimeout(() => {
    document.querySelector('.filter-input').value = q;
    filterProductsLocal(q);
  }, 100);
}

// ── MODALS ──
function closeModal(type) {
  if (type === 'addProduct') document.getElementById('addProductModal').classList.add('hidden');
  if (type === 'addCategory') document.getElementById('addCategoryModal').classList.add('hidden');
  const anyOpen = !document.getElementById('addProductModal').classList.contains('hidden') ||
    !document.getElementById('addCategoryModal').classList.contains('hidden');
  if (!anyOpen) document.getElementById('modalOverlay').classList.add('hidden');
}

function closeAllModals(e) {
  if (e.target === document.getElementById('modalOverlay')) {
    document.getElementById('addProductModal').classList.add('hidden');
    document.getElementById('addCategoryModal').classList.add('hidden');
    document.getElementById('modalOverlay').classList.add('hidden');
  }
}

// ── TOAST ──
let toastTimer;
function showToast(msg, isError = false) {
  const t = document.getElementById('toast');
  document.getElementById('toastMsg').textContent = msg;
  t.classList.remove('hidden', 'error');
  if (isError) t.classList.add('error');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.add('hidden'), 3500);
}

// ── HELPERS ──
function getEmoji(cat) {
  const map = { 'Electronics': '💻', 'Clothing': '👕', 'Books': '📚', 'Sports': '⚽', 'Food': '🍔', 'Home': '🏠', 'Beauty': '💄', 'Toys': '🧸' };
  return map[cat] || '📦';
}
function getCatEmoji(name) { return getEmoji(name); }
function loadingHTML() { return `<div class="loading-state"><div class="spinner"></div><p>Loading...</p></div>`; }
function errorHTML(msg) { return `<div class="empty-state"><div class="empty-state-icon">⚠️</div><h3>${msg}</h3></div>`; }
